import React, { useState } from "react";

export default function TextAnalysisApp() {
  const [text, setText] = useState("");
  const [analysisType, setAnalysisType] = useState("sentiment");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Update this with your actual webhook URL and credentials
  const WEBHOOK_URL = "http://localhost:5678/webhook-test/LLMS";
  const USERNAME = "llmtrail";
  const PASSWORD = "123456789";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setResult(null);

    const payload = {
      text,
      type: analysisType,
    };

    try {
      const response = await fetch(WEBHOOK_URL, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Authorization: "Basic " + btoa(`${USERNAME}:${PASSWORD}`), // ✅ fixed
  },
  body: JSON.stringify(payload),
});

if (!response.ok) {
  throw new Error(`HTTP error! Status: ${response.status}`); // ✅ fixed
}

      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error("Error:", err);
      setError("Failed to connect to the webhook. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      <div className="bg-white shadow-md rounded-2xl p-6 w-full max-w-lg">
        <h1 className="text-2xl font-bold mb-4 text-center">
          🧠 Text Analysis App
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea
            className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows="5"
            placeholder="Enter your text here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            required
          ></textarea>

          <select
            className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={analysisType}
            onChange={(e) => setAnalysisType(e.target.value)}
          >
            <option value="sentiment">Sentiment Analysis</option>
            <option value="summary">Summary</option>
          </select>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition font-semibold"
            disabled={loading}
          >
            {loading ? "Processing..." : "Analyze"}
          </button>
        </form>

        {error && (
          <p className="text-red-600 text-center mt-4 font-medium">{error}</p>
        )}

        {result && (
          <div className="mt-6 bg-gray-100 p-4 rounded-xl">
            {result.task === "sentiment" && (
              <div className="text-center">
                <h2 className="text-lg font-semibold mb-2">
                  Sentiment Result:
                </h2>
                <p className="text-xl font-bold text-blue-600">
                  {result.overall_sentiment}
                </p>
              </div>
            )}

            {result.task === "summary" && (
              <div>
                <h2 className="text-lg font-semibold mb-2">Summary:</h2>
                <p className="text-gray-800 mb-3">{result.summary}</p>

                {result.key_points && result.key_points.length > 0 && (
                  <>
                    <h3 className="text-md font-semibold mb-1">Key Points:</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {result.key_points.map((point, idx) => (
                        <li key={idx} className="text-gray-700">
                          {point}
                        </li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}