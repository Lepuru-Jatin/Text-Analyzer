import TextAnalysisApp from "./TextAnalysisApp";
function App() {
  return <TextAnalysisApp />;
}
export default App;